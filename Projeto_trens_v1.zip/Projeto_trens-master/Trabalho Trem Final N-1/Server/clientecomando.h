#ifndef CLIENTECOMANDO
#define CLIENTECOMANDO

struct Comando {
    int id;
    int velocidade;
    bool enable;
};

#endif // CLIENTECOMANDO

